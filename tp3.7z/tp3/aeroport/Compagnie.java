package aeroport;
import java.util.Scanner;


public class Compagnie {
	private String nomCompagnie;
	private static final int NB_PLACES_MAX= 210;
	private static final int NB_MAXIMUM_VOL = 10;
    private Vol tableauVol[];
	private int nbVols=0;

	//on donne un nom � la compagnie et on initialise le tableau des Vols d'avion
	public Compagnie(String nomCompa) {
		this.nomCompagnie=nomCompa;
		 tableauVol= new Vol [NB_MAXIMUM_VOL];
		/**
		 for(int i=0;i<9;i++) {
			tableauVol[i]=new Vol();
			nbVols++;
		}*/
	}
	//permet de voir si la valeur rechercher est d�j� inscrite dans le tableau
	private int rechercher (int rechercheNumVol) {
		int valeurRenvoye=0;
		for (int i=0; i< NB_MAXIMUM_VOL;i++) {
		if(rechercheNumVol==tableauVol[i].getNumeroVol()) {
			valeurRenvoye=i;
		}else {
			valeurRenvoye=-1;
		}
		
		}
		return valeurRenvoye;
	}
	//�a permet d'inserer un nouveau numero de vol dans le tableau si elle n'a pas d�j� utiliser
	public void inserer () {
		Scanner clavier = new Scanner(System.in);
		if(nbVols<NB_MAXIMUM_VOL) {
			int numeroInserer=clavier.nextInt();
			int reponse=rechercher(numeroInserer);
			if(reponse==-1){
				tableauVol[NB_MAXIMUM_VOL].setNumeroVol(numeroInserer);
				System.out.println("Quelle est votre destination");
				String destination=clavier.next();
				tableauVol[NB_MAXIMUM_VOL].setDestination(destination);
				System.out.println("Quelle est votre ville de d�part?");
				String villeDepart=clavier.next();
				tableauVol[NB_MAXIMUM_VOL].setVilleDepart(villeDepart);
				tableauVol[NB_MAXIMUM_VOL].setNbReservation(0);
			}else {
				System.out.println("Le num�ro de vol existe d�j�");
			}
 		}else {
			System.out.println("Le nombre de vol limite est rempli");
		}
		}
	//cette m�thode permet de retirer le nombre inscrit par l'usager
	public void retirer (int numVolARetirer) {
		int resultat=rechercher(numVolARetirer);
		if(resultat!=-1) {
				nbVols--;
				tableauVol[resultat]=tableauVol[nbVols] ;
				tableauVol[nbVols]= new Vol(-1,"","",-1);
			}
		}
	//permet de reserver une place
	public void reserver (int rechercheNumVol) {
		int reservationTot;
		int resultat=rechercher(rechercheNumVol);
		reservationTot=tableauVol[resultat].getNbReservation();
		
		if(reservationTot!= NB_PLACES_MAX);{
			tableauVol[resultat].setNbReservation(reservationTot++);
		} if(reservationTot>= NB_PLACES_MAX) {
			System.out.println("Il n'y a plus de place disponible pour r�server.");
		}
		
	}
	//affiche les informations obtenus 
	public void afficher (){
		for (int i=0; i<NB_MAXIMUM_VOL; i++) {
		System.out.println(" nom de compagnie " + nomCompagnie);
		tableauVol[i].afficher();
		}
	}
	

}
