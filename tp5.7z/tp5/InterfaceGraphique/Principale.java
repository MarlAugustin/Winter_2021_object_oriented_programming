package InterfaceGraphique;



public class Principale {
	public static void main(String[] args) {

	PoidsIdeal fenetrePrincipale = new PoidsIdeal();
	fenetrePrincipale.setVisible(true);
	fenetrePrincipale.setResizable(false);
}
}
