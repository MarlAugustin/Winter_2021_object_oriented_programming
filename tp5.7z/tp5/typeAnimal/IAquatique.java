package typeAnimal;

public interface IAquatique {
public abstract String vitDansEau();
}
