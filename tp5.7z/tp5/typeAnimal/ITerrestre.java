package typeAnimal;

public interface ITerrestre {
public abstract String vitSurTerre();
}
